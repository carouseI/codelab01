using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Run
{
    public class CharacterStats : MonoBehaviour
    {
      
    }
}
