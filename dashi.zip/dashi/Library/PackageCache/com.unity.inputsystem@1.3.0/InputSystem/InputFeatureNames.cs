namespace UnityEngine.InputSystem
{
    internal static class InputFeatureNames
    {
        public const string kRunPlayerUpdatesInEditMode = "RUN_PLAYER_UPDATES_IN_EDIT_MODE";
        public const string kDisableUnityRemoteSupport = "DISABLE_UNITY_REMOTE_SUPPORT";
    }
}
